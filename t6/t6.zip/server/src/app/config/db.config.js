module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "my-secret-pw",
  DB: "athletelist",
  ENABLE_MULTIPLE_STATEMENTS: true,
};
